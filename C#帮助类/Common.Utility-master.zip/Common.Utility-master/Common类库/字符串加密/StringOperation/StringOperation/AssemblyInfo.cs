﻿// Assembly StringOperation, Version 1.0.1662.20463

[assembly: System.Reflection.AssemblyVersion("1.0.1662.20463")]
[assembly: System.Reflection.AssemblyKeyName("")]
[assembly: System.Reflection.AssemblyKeyFile("")]
[assembly: System.Reflection.AssemblyDelaySign(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("")]
[assembly: System.Reflection.AssemblyProduct("")]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyTitle("")]
[assembly: System.Diagnostics.Debuggable(true, true)]

