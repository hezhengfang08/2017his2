using System;
using System.Collections.Generic;
using System.Text;

namespace DotNet.Utilities
{
    public static class ResourcesApi
    {
        public static string Win32_DeviceIoControlErr="�豸IO���ƴ���";
        public static string Win32_DeviceIoControlNotSupport = "�豸IO��֧��";
        public static string Win32_CurrentPlatformNotSupport = "��ǰϵͳ��֧��";
        public static string Win32_CurrentPlatformUnknown = "��ǰϵͳδ֪";

    }
}
