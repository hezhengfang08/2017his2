 
using System;
using System.Text;

namespace Solution.DataAccess.Model
{
    /// <summary>
    /// MyWorkLog表实体类
    /// </summary>
    public partial class MyWorkLog
    {

		int _Id = 0;
		/// <summary>
		/// 主键
		/// </summary>
		public int Id
		{
			get { return _Id; }
			set { _Id = value; }
		}

		string _work_name = "";
		/// <summary>
		/// 工作内容
		/// </summary>
		public string work_name
		{
			get { return _work_name; }
			set { _work_name = value; }
		}

		string _work_desrc = "";
		/// <summary>
		/// 工作描述
		/// </summary>
		public string work_desrc
		{
			get { return _work_desrc; }
			set { _work_desrc = value; }
		}

		DateTime _work_start = new DateTime(1900,1,1);
		/// <summary>
		/// 工作开始时间
		/// </summary>
		public DateTime work_start
		{
			get { return _work_start; }
			set { _work_start = value; }
		}

		DateTime _work_end = new DateTime(1900,1,1);
		/// <summary>
		/// 工作结束时间
		/// </summary>
		public DateTime work_end
		{
			get { return _work_end; }
			set { _work_end = value; }
		}

		string _work_stus = "";
		/// <summary>
		/// 工作状态
		/// </summary>
		public string work_stus
		{
			get { return _work_stus; }
			set { _work_stus = value; }
		}

		/// <summary>
        /// 输出实体所有值
        /// </summary>
        /// <returns></returns>
		public string ToString(){
			var sb = new StringBuilder();
			sb.Append("Id=" +　Id + "; ");
			sb.Append("work_name=" +　work_name + "; ");
			sb.Append("work_desrc=" +　work_desrc + "; ");
			sb.Append("work_start=" +　work_start + "; ");
			sb.Append("work_end=" +　work_end + "; ");
			sb.Append("work_stus=" +　work_stus + "; ");
			return sb.ToString();
        }

    } 

}


