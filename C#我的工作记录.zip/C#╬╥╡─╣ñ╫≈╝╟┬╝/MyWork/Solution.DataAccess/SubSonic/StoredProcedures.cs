﻿


  
using System;
using System.Data;
using SubSonic.Schema;
using SubSonic.DataProviders;

namespace Solution.DataAccess.DataModel{
	public partial class SPs{

        public static StoredProcedure P_Branch_GetMaxBranchCode(int Depth,int ParentId){
            StoredProcedure sp=new StoredProcedure("P_Branch_GetMaxBranchCode");
			
            sp.Command.AddParameter("Depth",Depth,DbType.Int32);
            sp.Command.AddParameter("ParentId",ParentId,DbType.Int32);
            return sp;
        }
        public static StoredProcedure P_ErrorLog_Delete(){
            StoredProcedure sp=new StoredProcedure("P_ErrorLog_Delete");
			
            return sp;
        }
        public static StoredProcedure P_LoginLog_Delete(){
            StoredProcedure sp=new StoredProcedure("P_LoginLog_Delete");
			
            return sp;
        }
        public static StoredProcedure P_Userlog_Delete(){
            StoredProcedure sp=new StoredProcedure("P_Userlog_Delete");
			
            return sp;
        }
	
	}
	
}
 