 
using System;

namespace Solution.DataAccess.DataModel {
        /// <summary>
        /// Table: MyWorkLog
        /// </summary>

        public class MyWorkLogTable {
			/// <summary>
			/// 表名
			/// </summary>
			public static string TableName {
				get{
        			return "MyWorkLog";
      			}
			}

			/// <summary>
			/// 主键
			/// </summary>
   			public static string Id{
			      get{
        			return "Id";
      			}
		    }
			/// <summary>
			/// 工作内容
			/// </summary>
   			public static string work_name{
			      get{
        			return "work_name";
      			}
		    }
			/// <summary>
			/// 工作描述
			/// </summary>
   			public static string work_desrc{
			      get{
        			return "work_desrc";
      			}
		    }
			/// <summary>
			/// 工作开始时间
			/// </summary>
   			public static string work_start{
			      get{
        			return "work_start";
      			}
		    }
			/// <summary>
			/// 工作结束时间
			/// </summary>
   			public static string work_end{
			      get{
        			return "work_end";
      			}
		    }
			/// <summary>
			/// 工作状态
			/// </summary>
   			public static string work_stus{
			      get{
        			return "work_stus";
      			}
		    }
                    
        }
}
