 
using System;
using SubSonic.Schema;
using SubSonic.DataProviders;
using System.Data;

namespace Solution.DataAccess.DataModel {
        /// <summary>
        /// Table: MyWorkLog
        /// Primary Key: Id
        /// </summary>

        public class MyWorkLogStructs: DatabaseTable {
            
            public MyWorkLogStructs(IDataProvider provider):base("MyWorkLog",provider){
                ClassName = "MyWorkLog";
                SchemaName = "dbo";
                

                Columns.Add(new DatabaseColumn("Id", this)
                {
	                IsPrimaryKey = true,
	                DataType = DbType.Int32,
	                IsNullable = false,
	                AutoIncrement = true,
	                IsForeignKey = false,
	                MaxLength = 0,
					PropertyName = "Id"
                });

                Columns.Add(new DatabaseColumn("work_name", this)
                {
	                IsPrimaryKey = false,
	                DataType = DbType.String,
	                IsNullable = false,
	                AutoIncrement = false,
	                IsForeignKey = false,
	                MaxLength = 50,
					PropertyName = "work_name"
                });

                Columns.Add(new DatabaseColumn("work_desrc", this)
                {
	                IsPrimaryKey = false,
	                DataType = DbType.String,
	                IsNullable = false,
	                AutoIncrement = false,
	                IsForeignKey = false,
	                MaxLength = 500,
					PropertyName = "work_desrc"
                });

                Columns.Add(new DatabaseColumn("work_start", this)
                {
	                IsPrimaryKey = false,
	                DataType = DbType.DateTime,
	                IsNullable = false,
	                AutoIncrement = false,
	                IsForeignKey = false,
	                MaxLength = 0,
					PropertyName = "work_start"
                });

                Columns.Add(new DatabaseColumn("work_end", this)
                {
	                IsPrimaryKey = false,
	                DataType = DbType.DateTime,
	                IsNullable = false,
	                AutoIncrement = false,
	                IsForeignKey = false,
	                MaxLength = 0,
					PropertyName = "work_end"
                });

                Columns.Add(new DatabaseColumn("work_stus", this)
                {
	                IsPrimaryKey = false,
	                DataType = DbType.String,
	                IsNullable = false,
	                AutoIncrement = false,
	                IsForeignKey = false,
	                MaxLength = 10,
					PropertyName = "work_stus"
                });
                    
                
                
            }

            public IColumn Id{
                get{
                    return this.GetColumn("Id");
                }
            }
				
            
            public IColumn work_name{
                get{
                    return this.GetColumn("work_name");
                }
            }
				
            
            public IColumn work_desrc{
                get{
                    return this.GetColumn("work_desrc");
                }
            }
				
            
            public IColumn work_start{
                get{
                    return this.GetColumn("work_start");
                }
            }
				
            
            public IColumn work_end{
                get{
                    return this.GetColumn("work_end");
                }
            }
				
            
            public IColumn work_stus{
                get{
                    return this.GetColumn("work_stus");
                }
            }
				
            
                    
        }
        
}
