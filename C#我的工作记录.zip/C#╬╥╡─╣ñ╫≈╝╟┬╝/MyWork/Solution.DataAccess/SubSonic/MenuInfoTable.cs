 
using System;

namespace Solution.DataAccess.DataModel {
        /// <summary>
        /// Table: MenuInfo
        /// </summary>

        public class MenuInfoTable {
			/// <summary>
			/// 表名
			/// </summary>
			public static string TableName {
				get{
        			return "MenuInfo";
      			}
			}

			/// <summary>
			/// 
			/// </summary>
   			public static string Id{
			      get{
        			return "Id";
      			}
		    }
			/// <summary>
			/// 
			/// </summary>
   			public static string Name{
			      get{
        			return "Name";
      			}
		    }
			/// <summary>
			/// 
			/// </summary>
   			public static string Url{
			      get{
        			return "Url";
      			}
		    }
			/// <summary>
			/// 
			/// </summary>
   			public static string ParentId{
			      get{
        			return "ParentId";
      			}
		    }
			/// <summary>
			/// 
			/// </summary>
   			public static string Sort{
			      get{
        			return "Sort";
      			}
		    }
			/// <summary>
			/// 
			/// </summary>
   			public static string Depth{
			      get{
        			return "Depth";
      			}
		    }
			/// <summary>
			/// 
			/// </summary>
   			public static string IsDisplay{
			      get{
        			return "IsDisplay";
      			}
		    }
			/// <summary>
			/// 
			/// </summary>
   			public static string IsMenu{
			      get{
        			return "IsMenu";
      			}
		    }
                    
        }
}
