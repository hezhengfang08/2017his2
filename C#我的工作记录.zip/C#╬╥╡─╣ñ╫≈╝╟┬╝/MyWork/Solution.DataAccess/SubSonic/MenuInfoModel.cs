 
using System;
using System.Text;

namespace Solution.DataAccess.Model
{
    /// <summary>
    /// MenuInfo表实体类
    /// </summary>
    public partial class MenuInfo
    {

		int _Id = 0;
		/// <summary>
		/// 
		/// </summary>
		public int Id
		{
			get { return _Id; }
			set { _Id = value; }
		}

		string _Name = "";
		/// <summary>
		/// 
		/// </summary>
		public string Name
		{
			get { return _Name; }
			set { _Name = value; }
		}

		string _Url = "";
		/// <summary>
		/// 
		/// </summary>
		public string Url
		{
			get { return _Url; }
			set { _Url = value; }
		}

		int _ParentId = 0;
		/// <summary>
		/// 
		/// </summary>
		public int ParentId
		{
			get { return _ParentId; }
			set { _ParentId = value; }
		}

		int _Sort = 0;
		/// <summary>
		/// 
		/// </summary>
		public int Sort
		{
			get { return _Sort; }
			set { _Sort = value; }
		}

		int _Depth = 0;
		/// <summary>
		/// 
		/// </summary>
		public int Depth
		{
			get { return _Depth; }
			set { _Depth = value; }
		}

		byte _IsDisplay = 0;
		/// <summary>
		/// 
		/// </summary>
		public byte IsDisplay
		{
			get { return _IsDisplay; }
			set { _IsDisplay = value; }
		}

		byte _IsMenu = 0;
		/// <summary>
		/// 
		/// </summary>
		public byte IsMenu
		{
			get { return _IsMenu; }
			set { _IsMenu = value; }
		}

		/// <summary>
        /// 输出实体所有值
        /// </summary>
        /// <returns></returns>
		public string ToString(){
			var sb = new StringBuilder();
			sb.Append("Id=" +　Id + "; ");
			sb.Append("Name=" +　Name + "; ");
			sb.Append("Url=" +　Url + "; ");
			sb.Append("ParentId=" +　ParentId + "; ");
			sb.Append("Sort=" +　Sort + "; ");
			sb.Append("Depth=" +　Depth + "; ");
			sb.Append("IsDisplay=" +　IsDisplay + "; ");
			sb.Append("IsMenu=" +　IsMenu + "; ");
			return sb.ToString();
        }

    } 

}


